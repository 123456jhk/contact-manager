I have written the two python codes and attached into the Zip file.
While signing the page it will ask for email, password, and secret code. After validating the details it will create the user account.
Users should have signed in to the page with their credentials. After successfully login into the page, the User would allow saving the contacts by entering their details.

procedure for running file:

1.Open Spyder and select the file path in which path you have stored the files
2.Select the Files folder and open two files
3.Then Run the files, you will get the Output in the window prompt.